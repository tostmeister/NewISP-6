﻿using System;

namespace LR_10_Двусвязные_Списки
{
    public class LinkedList<T>
    {
        Item<T> head;
        Item<T> tail;

        public void Add(T name, T quantity, T id, T dateOfManufacture)
        {
            Item<T> node = new Item<T>(name, quantity, id, dateOfManufacture);

            if (head == null)
            {
                head = node;
            }
            else
            {
                tail.Next = node;
                node.Previous = tail;
            }

            tail = node;
        }

        public void Remove(T name)
        {
            Item<T> current = head;

            while (current != null)
            { 
                if (current.Name.Equals(name))
                    break;

                current = current.Next;
            }

            if (current != null)
                current.Next.Previous = current.Previous;
            else
                tail = current.Previous;

            if (current.Previous != null)
                current.Previous.Next = current.Next; //задать вопрос по этому гавну
            else
                head = current.Next;
        }

        public void Clean()
        {
            Console.Clear();

            head = null;
            tail = null;

            Console.WriteLine("Список очищен.\n");
        }

        public bool isEmpty()
        {
            if (head == null)
                return true;
            else
                return false;
        }

        public bool CheckUniqueID(T id)
        {
            Item<T> current = head;

            while (current != null)
            {
                if (current.ID.Equals(id))
                {
                    return false;
                }

                current = current.Next;
            }
            return true;
        }

        public void FindNameOrID(T product)
        {
            Item<T> current = head;

            int countItem = 0;

            while (current != null)
            {
                if (current.Name.Equals(product) || current.ID.Equals(product))
                {
                    Console.WriteLine("\nНайдено сходство:");

                    Console.WriteLine($"Название: {current.Name}, " +
                        $"Кол-во: {current.Quantity}, " +
                        $"ID: {current.ID}, " +
                        $"Дата производства: {current.DateOfManufacture}\n");

                    countItem++;
                }
                else if(current.Next == null && countItem == 0)
                {
                    Console.WriteLine($"\nПо запросу '{product}' ничего не найдено.\n");
                }

                current = current.Next;
            }
        }

        public void Output()
        {
            Item<T> current = head;

            if (isEmpty() == true)
            {
                Console.WriteLine("Список пуст. Добавьте продукты.\n");
                return;
            }

            Console.WriteLine("Продукты в списке: ");

            while (current != null)
            {
                Console.WriteLine($"Название: {current.Name}, " +
                    $"Кол-во: {current.Quantity}, " +
                    $"ID: {current.ID}, " +
                    $"Дата производства: {current.DateOfManufacture}");

                current = current.Next;
            }

            Console.WriteLine();
        }
    }
}