﻿using System;

namespace LR_10_Двусвязные_Списки
{
    class Program
    {
        static LinkedList<object> linkedList = new LinkedList<object>();

        static void AddToList()
        {
            Console.Clear();

            Random rand = new Random();
            int id = rand.Next(1000000, 9999999);

            while (linkedList.CheckUniqueID(id) != true)
            {
                id += 666;
            }

            Console.Write("Введите название продукта: ");
            string name = Console.ReadLine();

            Console.Write("Введите количество продукта: ");
            int quantity = int.Parse(Console.ReadLine());

            Console.Write("Введите дату производства: ");
            string dateOfManufacture = Console.ReadLine();

            linkedList.Add(name, quantity, id, dateOfManufacture);

            Console.Clear();

            Console.WriteLine("Продукт добавлен.\n");
        }

        static void RemoveAtList()
        {
            Console.Clear();

            if (linkedList.isEmpty() == true)
            {
                Console.WriteLine("Список пуст. Добавьте продукты.\n");
                return;
            }

            linkedList.Output();

            Console.Write("Введите название продукта, который хотите удалить: ");
            string name = Console.ReadLine();

            linkedList.Remove(name);

            Console.Clear();

            Console.WriteLine("Продукт удалён из списка.\n");
        }

        static void SearchName()
        {
            Console.Clear();

            if (linkedList.isEmpty() == true)
            {
                Console.WriteLine("Список пуст. Добавьте продукты.\n");
                return;
            }

            Console.Write("Введите название продукта, который хотите найти: ");
            string name = Console.ReadLine();

            linkedList.FindNameOrID(name);
        }

        static void SearchID()
        {
            Console.Clear();

            if (linkedList.isEmpty() == true)
            {
                Console.WriteLine("Список пуст. Добавьте продукты.\n");
                return;
            }

            Console.Write("Введите id продукта, который хотите найти: ");
            int id = int.Parse(Console.ReadLine());

            linkedList.FindNameOrID(id);
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Что вы хотите сделать:\n" +
                    "1) Добавить продукт.\n" +
                    "2) Удалить продукт.\n" +
                    "3) Проверка списка на пустоту.\n" +
                    "4) Поиск продукта по названию.\n" +
                    "5) Поиск продукта по id.\n" +
                    "6) Очистить список.\n" +
                    "7) Посмотреть продукты в списке.\n");

                Console.Write("Ваш выбор: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddToList();
                        break;
                    case 2:
                        RemoveAtList();
                        break;
                    case 3:
                        Console.Clear();

                        Console.WriteLine(linkedList.isEmpty() == true ?
                            "Список пуст.\n" : "Список не является пустым.\n");
                        break;
                    case 4:
                        SearchName();
                        break;
                    case 5:
                        SearchID();
                        break;
                    case 6:
                        linkedList.Clean();
                        break;
                    case 7:
                        Console.Clear();
                        linkedList.Output();
                        break;
                }
            }
        }
    }
}